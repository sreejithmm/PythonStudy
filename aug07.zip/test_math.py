
name: str

def square(x: int) -> int:
    return x*x

name = "John"
print(square(10))
print(square(34))
name = 34.5

