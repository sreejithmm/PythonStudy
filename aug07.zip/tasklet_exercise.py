"""
Implement the 'Runqueue' class that allows adding generators into
a runqueue and schedule them.

Under the '__main__' namespace, there is a sample use-case.
Running this program should generate result as below:
    foo: counting 0
    bar: counting 0
    foo: counting 1
    bar: counting 1
    foo: counting 2
    bar: counting 2
    foo: counting 3
    bar: counting 3
    foo: counting 4
    bar: counting 4
    foo: counting 5
    foo: counting 6
    foo: counting 7
    foo: counting 8
    foo: counting 9
"""


class Runqueue:

    def __init__(self):
        from collections import deque
        self.rq = deque()

    def add(self, fn, * args, ** kwargs):
        task = fn(* args, ** kwargs)
        self.rq.append(task)

    def schedule(self):
        i = 0
        while True:
            try:
                task = self.rq[i]
                next(task)
                i += 1
                i %= len(self.rq)
            except StopIteration:
                self.rq.remove(task)


if __name__ == '__main__':

    def foo(x):
        for i in range(x):
            yield
            print("foo: counting {}".format(i))

    def bar(n):
        for i in range(n):
            yield
            print("bar: counting {}".format(i))

    runqueue = Runqueue()
    runqueue.add(foo, 10)
    runqueue.add(bar, 6)
    runqueue.schedule()  # Schedule tasklets (generator functions) added into the runqueue
