a = 10

def testfn():
    a = 20
    def foo():
        print("In foo(): a =", a) # nested-static scope / external scope
                                  # closure scope

    return foo

fn = testfn()
fn()


