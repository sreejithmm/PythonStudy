class User:
    def __init__(self):
        print("User object created...")

    def __del__(self):
        raise ValueError("A sample exception...")

try:
    u = User()
    print("Created user...")
    del u
except Exception as e:
    print("Caught exception: e =", e)

