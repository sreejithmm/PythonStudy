a = 10

def testfn():
    a = 20 # External scope / Nested static scope
    def bar():  # L-E-G-B -> Local, External, Global, Builtin
        print("In bar: a =", a)

    bar()

testfn()

