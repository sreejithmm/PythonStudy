class Test:

    def __init__(self):
        print("__init__ method invoked...")

    def __del__(self):
        print("__del__ method invoked...")


print("Start of program...")
t1 = Test()
t2 = t1
t3 = t2
print(t1, t2, t3)

del t1
print("t1 is deleted...")

t2 = 100
print("t2 is now", t2)

t3 = 200
print("t3 is now", t3)

print("End of program...")


