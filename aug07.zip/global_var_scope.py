a = 100

def testfn():
    print("In testfn: a =", a)

testfn()