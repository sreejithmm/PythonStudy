class CommandDispatch:
    def __init__(self):
        self.dispatch = {}
    
    def for_command(self, command):
        def decorate(fn):
            self.dispatch[command] = fn
        return decorate
            
    
    def input(self, fn): 
        self.inputfn = fn
    
    def invalid(self, fn):
        self.invalidfn = fn
    
    def run(self):
        while True:
            args = self.inputfn()
            command = args[0]
            self.dispatch.get(command, self.invalidfn)(*args)