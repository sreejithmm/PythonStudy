def testfn():
    def foo():
        print("foo() being invoked...")

    return foo

fn = testfn()
fn()


