
def testfn():
    a = 20 # External scope / Nested static scope
    def bar():  # L-E-G-B -> Local, External, Global, Builtin
        print("In bar: a =", a)

    return bar

fn = testfn()

fn() # Accessor function
