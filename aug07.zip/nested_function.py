a = 10

def testfn():
    a = 20
    def foo():
        print("In foo: a =", a) # Resolve via External / Nested-static scope
    foo()
    foo()
    foo()

testfn()
#foo()