color = "white"  # Global name (variable)

class Car:
    color = 'red'  # Class attribute # Car.color = 'red'

    def __init__(self):
        color = "green"  # Local name (variable)
        self.color = "blue"  # Instance attribute

    def drive(self):
        print("Driving a", color, "car")
        print("Car.color =", Car.color)
        print("self.color =", self.color)

c = Car()
c.drive()
