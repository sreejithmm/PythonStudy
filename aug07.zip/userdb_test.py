from simple_db_oo_implementation import Database

with Database(filename="userdata.dat",
              fields=("name", "password", "fullname"),
              primary_key="name") as userdb:

    userdb.add(userdb.Entity(name="john", password="john123", fullname="John Doe"))
    userdb.add(userdb.Entity(name="smith", password="smith123", fullname="Adrian Smith"))

with Database(filename="userdata.dat",
              fields=("name", "password", "fullname"),
              primary_key="name") as userdb:
    userdb["john"].password = "welcome"
    del userdb["smith"]
    print(userdb["john"].fullname)

