class Record:
    def __init__(self, **fields):
        self.__dict__.update(**fields)

    def __str__(self):
        r = "Record(" + \
         ",".join(f"{k}='{v}'" for k, v in self.__dict__.items()) + ")"
        return r

    def __getitem__(self, field):
        if field not in self.__dict__:
            raise KeyError(f"Invalid field name - {field}")
        else:
            return self.__dict__[field]

    def __setitem__(self, field, value):
        if field not in self.__dict__:
            raise KeyError(f"Invalid field name - {field}")
        else:
            self.__dict__[field] = value

    __repr__ = __str__

class Table:
    def __init__(self, filename, fields, primary_key=None, sep=":"):
        self.filename, self.fields, self.sep = filename, fields, sep
        if primary_key is None:
            self.primary_key = fields[0]
        elif primary_key not in fields:
            raise KeyError(f"Primary key '{primary_key}' not in fields '{fields}'")
        else:
            self.primary_key = primary_key

    def create_record(self, **fields):
        if fields.keys() != set(self.fields):
            raise KeyError(f"Fields mismatch: expected {self.fields}, found {tuple(fields.keys())}")
        else:
            return Record(**fields)

    def parse(self):
        self.db = {}
        with open(self.filename) as infile:
            for line in infile:
                field_values = line.strip().split(self.sep)
                #print(field_values)
                rec = dict(zip(self.fields, field_values))
                record = self.create_record(**rec)
                key = record[self.primary_key]
                self.db[key] = record

    rollback = parse

    def commit(self):
        with open(self.filename, "w") as outfile:
            for rec in self.db.values():
                print(self.sep.join(rec.__dict__.values()), file=outfile)

    def __enter__(self):
        self.parse()
        return self

    def __exit__(self, et, ev, tb):
        if et is None:
            self.commit()
        else:
            self.rollback()

    def __getitem__(self, key):
        return self.db[key]

    def __delitem__(self, key):
        del self.db[key]

    def __setitem__(self, key, record):
        if not hasattr(self, 'db'):
            raise KeyError("Table is not parsed")
        if key != record.__dict__[self.primary_key]:
            raise KeyError("Primary key mismatch")
        elif key not in self.db:
            self.db[key] = record
        else:
            self.db[key].__dict__.update(record.__dict__)
