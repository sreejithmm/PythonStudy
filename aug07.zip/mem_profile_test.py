from memory_profiler import profile
import shelve

@profile
def my_func():

    a =  { str(x): x*x for x in  range(100000) }
    print("Created dictionary...")
    b = shelve.open("squares")
    print("Loaded shelve object...")

    v = a["456"]
    v1 = b["456"]

    v = a["7892"]
    v1 = b["7892"]

    b.close()
    del a

if __name__ == '__main__':
    my_func()
