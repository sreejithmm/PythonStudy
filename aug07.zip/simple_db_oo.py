class Table:
    def __init__(self, filename, fields, primary_key=None):
        pass # TODO

    def __enter__(self):
        pass # TODO
        return self

    def __exit__(self, et, ev, tb):
        if et is None:
            pass # TODO: commit -> store to file
        else:
            pass # TODO: rollback -> re-parse the file
        
    def __getitem__(self, key):
        pass # TODO
    
    def __setitem__(self, key, record):
        pass # TODO
    
    def __delitem__(self, key):
        pass # TODO
    

class Record:
    def __init__(self, **fields):
        pass

    def __setitem__(self, key, value):
        pass

    def __getitem__(self, key):
        pass
    