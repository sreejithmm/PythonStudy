from flask import Flask

app = Flask("hello_world")


@app.route("/")
def home_page():
    return "<h1>This is home page</h1>"

@app.route("/about")
def about_page():
    return "<h1>About me</h1>"

if __name__ == '__main__':
    app.run()

