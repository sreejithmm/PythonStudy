class User:
    def __del__(self):
        print("User destroyed.")

class Car:
    def __del__(self):
        print("Car destroyed.")

u = User()
c = Car()

u.owns = c
c.owner = u

print("Created a user and a car")

