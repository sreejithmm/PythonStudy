a = [100, 200]

def testfn():
    print("In testfn: a =", a)
    a = 300

testfn()
print("In main: a =", a)
