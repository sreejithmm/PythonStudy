from chain_of_responsibility import ChainOfResponsibility

data = [ (10, 20), (33, 66), (23, 12)]

tests = ChainOfResponsibility(data)

@tests.add
def add(x, y):
    return x+y

@tests.add
def mul(x, y):
    return x*y

@tests.add
def pow(x, y):
    return x ** y

@test.add
def divide(x, y):
    return x / y

if __name__ == '__main__':
    tests.run()

