#DictStore = type('DictStore', (dict,), {"filename": "dictstore.dat"})

class DictStore(dict):
    filename = "dictstore.dat"

print(DictStore)
#OUTPUT: <class '__main__.DictStore'>

data = DictStore()

print(data)
#OUTPUT: {}


