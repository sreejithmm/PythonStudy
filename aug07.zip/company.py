staff = {"adrian", "jones"}

def hire(m):
    staff.add(m)

def fire(m):
    if m in ("adrian", "jones"):
        raise ValueError("Cannot fire founding members...")
    staff.remove(m)

def show():
    print(", ".join(staff))
