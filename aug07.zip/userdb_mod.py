"""A simple user manager to manage users stored in a text file
(users.dat) in the following format:
   #username:password:fullname
   hansson:heine123:David Hansson
   larry:larry567:Larry Wall
   rossum:guido11:Guido Rossum
   steve:steve123:Steven Bourne
   korn:dk1122:David Korn

Provide the following functionality for usage:
(Make sure that your implementations passes all the below tests)

    >>> import userdb_mod as users

    >>> users.create_dummy_user_records()

    >>> users.add("adrian", "ad123", "Adrian Smith")

    >>> users.add("adrian", "ad444", "Adrian Smith")
    Traceback (most recent call last):
    ...
    ValueError: user 'adrian' already exists in database

    >>> users.mod(name="adrian", password="welcome")

    >>> users.mod(name="john", password="john123")
    Traceback (most recent call last):
    ...
    ValueError: user 'john' does not exist in database

    >>> users.remove(name="adrian")

    >>> users.remove(name="adrian")
    Traceback (most recent call last):
    ...
    ValueError: user 'adrian' does not exist in database

    >>> users.add(name="john", password="john123", fullname="John Doe")


"""

def create_dummy_user_records():
    """Create dummy user records for the doctests
    """
    records="""hansson:heine123:David Hansson
larry:larry567:Larry Wall
rossum:guido11:Guido Rossum
steve:steve123:Steven Bourne
korn:dk1122:David Korn"""

    with open("users.dat", "w") as out:
        out.write(records)

def parse_users():
    with open("users.dat") as src:
        users = {}

        for line in src:
            name, password, fullname = line.strip().split(":")
            rec = {
                    "name": name,
                    "password": password,
                    "fullname": fullname
            }
            users[name] = rec
    return users

def store_users(users):
    with open("users.dat", "w") as out:
        for rec in users.values():
            print("{}:{}:{}".format(rec["name"],
                                    rec["password"],
                                    rec["fullname"]), file=out)


def add(name, password, fullname):
    """
    Add a new user into the users database (file) in the
    form name:password:fullname

    The username (passed as 'name' parameter) must be unique.

    >>> import userdb_mod as users
    >>> users.add("ritchie", "dmr123", "Dennis Ritchie")
    >>> users.add("ritchie", "welcome", "Dennis M Ritchie")
    Traceback (most recent call last):
    ...
    ValueError: user 'ritchie' already exists in database
    """
    users = parse_users()
    if name in users:
        raise ValueError(f"user '{name}' already exists in database")
    else:
        users[name] = {"name": name, "password": password, "fullname": fullname}
        store_users(users)

def mod(name, password=None, fullname=None):
    """
    Changes user information in the users database.

    The username (passed as 'name' parameter) must exist.

    >>> import userdb_mod as users
    >>> users.mod("ritchie", fullname="Dennis M Ritchie")
    >>> users.mod("cutler", password="dave123")
    Traceback (most recent call last):
    ...
    ValueError: user 'cutler' does not exist in database
    """
    users = parse_users()
    if name not in users:
        raise ValueError(f"user '{name}' does not exist in database")
    else:
        if password: users[name]["password"] = password
        if fullname: users[name]["fullname"] = fullname
        store_users(users)


def remove(name):
    """
    Removes a user record from the users database.

    The username (passed as 'name' parameter) must exist.

    >>> import userdb_mod as users
    >>> users.remove("ritchie")
    >>> users.remove("cutler")
    Traceback (most recent call last):
    ...
    ValueError: user 'cutler' does not exist in database
    """
    users = parse_users()
    if name not in users:
        raise ValueError(f"user '{name}' does not exist in database")
    else:
        del users[name]
        store_users(users)


if __name__ == '__main__':
    from doctest import testmod
    testmod()

