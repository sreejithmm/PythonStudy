a = 10

def testfn():
    global a
    print("In testfn: a =", a)
    a = 20

testfn()
print("In main: a =", a)

