from pubsub import PubSub

ps = PubSub()

@ps.subscribe("connect")
def on_connect(host):
    print("Handling connection to", host)

@ps.subscribe("exit")
def on_exit(host):
    print("Cleaning up resources for", host)


def run():
    print("Running the server...")
    ps.publish("connect", "localhost")
    print("working...")
    ps.publish("exit", "localhost")

if __name__ == '__main__':
    run()



