# coding: utf-8
# %load command_dispatch.py
class CommandDispatch:

    def __init__(self, prompt):
        self.prompt = prompt
        self.dispatch = {}

    def for_command(self, command):
        def decorate(fn):
            self.dispatch[command] = fn
        return decorate

    def invalid(self, fn):
        self.invalidfn = fn

    def input(self, fn):
        self.inputfn = fn

    def run(self):
        while True:
            args = self.inputfn(self.prompt)
            self.dispatch.get(args[0], self.invalidfn)(*args)
