class Company:

    def __init__(self, *founders):
        self.__staff = set(founders)
        self.__founders = founders

    def hire(self, m):
        self.__staff.add(m)

    def fire(self, m):
        if m in self.__founders:
            raise ValueError("Cannot fire founding members...")
        self.__staff.remove(m)

    def show(self):
        print(", ".join(self.__staff))
