class DB:
    def __init__(self, conn):
        self.conn = conn

    def __enter__(self):
        import sqlite3
        self.dbconn = sqlite3.connect(self.conn)
        self.cursor = self.dbconn.cursor()
        return self

    def query(self, query):
        self.cursor.execute(query)

    def __exit__(self, et, ev, tb):
        if et is None:
            self.dbconn.commit()
        else:
            self.dbconn.rollback()
        self.dbconn.close()

if __name__ == '__main__':
    with DB("testdb") as db:
        db.query("INSERT INTO staff(name, role) VALUES('john', 'admin'")
        # ...
    print("End program...")