#from simple_db_oo_implementation import Table

class Record:
    def __init__(self, **kwargs):
        self.__dict__.update(kwargs)

    def __str__(self):
        return f"{self.__class__.__name__}(" + \
                ", ".join(f"{k}='{v}'" for k, v in self.__dict__.items()) + \
                ")"
    __repr__ = __str__


class Table:
    def __init__(self, filename, fields, primary_key):
        self.filename = filename
        self.fields = fields
        self.primary_key = primary_key

    def create_record(self, **fields):
        pass

    def __setitem__(self, key, rec):
        pass

    def __getitem__(self, key):
        pass

    def __delitem__(self, key):
        pass

    def parse(self):
        pass # Open the file for reading and read them

    def commit(self):
        pass # Open the file for writing and overwrite with in-memory data

    def rollback(self):
        pass

    def __enter__(self):
        self.parse()

    def __exit__(self, et, ev, tb):
        if et is not None:
            self.rollback()
        else:
            self.commit()


if __name__ == '__main__':

    with Table(filename="userdata.dat",
               fields=("name", "password", "fullname"),
               primary_key="name") as users:

        users["john"] = users.create_record(name="john",
                                       password="john123",
                                       fullname="John Doe")

        users["smith"] = users.create_record(name="smith",
                                        password="smith123",
                                        fullname="Adrian Smith")

    with Table(filename="userdata.dat",
                  fields=("name", "password", "fullname"),
                  primary_key="name") as users:
        users["john"].password = "welcome"
        del users["smith"]
        print(users["john"].fullname)
