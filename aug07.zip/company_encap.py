def company(*founders):
    staff = set(founders)

    def hire(m):
        staff.add(m)

    def fire(m):
        if m in founders:
            raise ValueError("Cannot fire founding members...")
        staff.remove(m)

    def show():
        print(", ".join(staff))

    return hire, fire, show
