class User:
    def __init__(self):
        print("New user created: self =", self)

    def __del__(self):
        print(f"User {self} is being freed from memory")

u1 = User()
u2 = u1
u3 = u2
print(f"u1 = {id(u1)}, u2 = {id(u2)}, u3 = {id(u3)}")

del u1
print("u1 was deleted.")

del u2
print("u2 was deleted.")

u3 = 100
print(f"u3 is set to {u3}")
