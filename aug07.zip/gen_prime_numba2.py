"""
A simple python program to test CPU performance by
generating a series of prime numbers
"""
from numba import jit, boolean, int32, void

NUM_PRIMES = 100000

@jit
def is_prime(number):
    "Returns True if 'number' is prime"
    limit = int(number ** 0.5) + 1
    for i in range(2, limit):
        if number % i == 0:
            return False
    return True

@jit
def gen_prime(num):
    "Generates first 'num' series of prime numbers"
    i = 2
    while num:
        if is_prime(i):
            print(i)
            num -= 1
        i += 1

from time import time

print("Generating %d prime numbers..." % NUM_PRIMES)
start = time()
gen_prime(NUM_PRIMES)
duration = time() - start
print("gen_prime(%d) took %f seconds" % (NUM_PRIMES, duration))

