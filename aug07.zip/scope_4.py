color = "white"          # Global name

class Car:
    color = "red"        # Class attribute 

    def __init__(self):
        color = "green"  # Local variable/name
        self.color = "blue"  # Instance attribute

    def drive(self):
        print("Driving a", color, "car")
        print("Car.color =", Car.color)
        print("self.color =", self.color)
        Car.color = "yellow"


c = Car() # Construction expression
c.drive()
print("In main, Car.color =", Car.color)

