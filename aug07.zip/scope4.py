staff = ["John", "Sam"]

def testfn():
    print("In testfn: staff =", staff)
    staff = ["Adrian", "Sam"]

testfn()
print("In main: staff =", staff)
