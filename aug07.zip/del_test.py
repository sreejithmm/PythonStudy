class User:
    def __init__(self):
        print("User object instantiated")

    def __del__(self):
        print("User object being destroyed")

u1 = User()
u2 = u1
u3 = u1
print(u1, u2, u3, sep="\n")
print()

del u1
print("u1 was deleted")

u2 = 100
print("u2 is set to 100")

u3 = "Hello world"
print("u3 is set to", u3)