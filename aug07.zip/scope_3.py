a = [10, 20, 30]

def testfn():
    print("In testfn: a =", a)
    #a = [100, 20, 30]
    a[0] = 100

testfn()
print("In main: a =", a)

