from flask import Flask

app = Flask("myapp")

@app.route("/")
def home_page():
    return "<h1>Hello world</h1>";


@app.route("/about")
def about_page():
    return "<h1>About page!</h1>";

if __name__ == '__main__':
    app.run()

