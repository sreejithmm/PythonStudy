from collections import deque

class Queue:
    def __init__(self):
        self.queue = deque()

    def __rrshift__(self, v):
        self.queue.appendleft(v)

    def __lshift__(self, v):
        self.queue.append(v)

    def __rshift__(self, dest):
        dest.queue.appendleft(self.queue.pop())
        return dest

    def __str__(self):
        return f"Queue({list(self.queue)})"

if __name__ == '__main__':
    q = Queue()
    2 >> q
    3 >> q
    4 >> q

    q << 10
    q << 11
    q << 12

    r = Queue()
    q >> r
    q >> r
    q >> r

    print(q)
    print(r)


