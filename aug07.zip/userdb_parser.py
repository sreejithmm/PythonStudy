def parse(filename):
    with open(filename) as src:
        users = {}

        for line in src:
            name, password, fullname = line.rstrip().split(":")
            rec = {
                    "name": name,
                    "password": password,
                    "fullname": fullname
            }
            users[name] = rec
    return users

def store(users, filename):
    with open(filename, "w") as out:
        for rec in users.values():
            print("{}:{}:{}".format(rec["name"],
                                    rec["password"],
                                    rec["fullname"]), file=out)

if __name__ == '__main__':
    users = parse("userdb.dat")
    print(users["john"]["password"])
    print(users)
    users["john"]["password"] = "welcome123"
    users["sam"]["fullname"] = "aaaa bbb ccc ddd"
    del users["larry"]
    print(users)
    store(users, "userdbnew.dat")

