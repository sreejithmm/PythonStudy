# coding: utf-8
def to_upper(fn): # Decorator function mostly deal with cross-cutting concerns
    def wrap():
        return fn().upper()
    return wrap

@to_upper
def welcome():
    return "Welcome to Python"

@to_upper
def greet():
    return "Hello world"

#greet = to_upper(greet)
#welcome = to_upper(welcome)

print(greet())
print(greet())

print(welcome())
