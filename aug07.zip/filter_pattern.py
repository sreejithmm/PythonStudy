from subprocess import Popen, PIPE, DEVNULL, STDOUT
import shlex
import sys

STDERR = 3

class Run:
    def __init__(self, command, **kwargs):
        self.command = shlex.split(command)
        self.kwargs = kwargs

    def __or__(self, other):
        self.kwargs["stdout"] = PIPE
        proc = Popen(self.command, **self.kwargs)
        other.kwargs["stdin"] = proc.stdout
        return other

    def __gt__(self, outstream):
        if outstream == STDOUT:
            self.kwargs["stdout"] = sys.stdout
        elif outstream == STDERR:
            self.kwargs["stdout"] = sys.stderr
        else:
            self.kwargs["stdout"] = outstream
        with Popen(self.command, **self.kwargs) as proc:
            proc.wait()


if __name__ == '__main__':
    Run("ls -l") | Run("tac") | Run("tail -1") > STDOUT
