def testfn():
    def foo():
        print("foo() being invoked...")

    foo()
    foo()
    foo()

testfn()
foo()


