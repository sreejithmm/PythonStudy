class Logger:
    def __init__(self, filename):
        print("__init__ being invoked...")
        self.filename = filename


    def start(self):
        self.file = open(self.filename, "a")
        return self

    def stop(self):
        self.file.close()

    def __enter__(self):
        print("__enter__ being invoked...")
        self.start()
        return self

    def __exit__(self, et, ev, tb):
        print("__exit__ being invoked...")
        self.stop()
        if et is None:
            print("Exit was graceful...")
        else:
            print("*** With block had an exception: ", ev)

    def log(self, msg):
        from time import ctime
        print(f"{ctime()}: {msg}", file=self.file)


if __name__ == '__main__':
    #obj = Logger("test.log")
    #with obj as logger:

    with Logger("test.log") as logger:
        print("Inside with block...")
        logger.log("Hello world")
        #3 / 0
        logger.log("welcome to python")

    logger = Logger("test.log")
    logger.start()
    logger.log("Hello")
    logger.log("World")
    logger.stop()

    print("Outside with block...")